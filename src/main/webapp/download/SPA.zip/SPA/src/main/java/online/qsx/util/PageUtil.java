package online.qsx.util;

/**
 * Created by 8888 on 2018/1/15.
 */
public class PageUtil {
    public static final int PAGE_SIZE=6;
}
